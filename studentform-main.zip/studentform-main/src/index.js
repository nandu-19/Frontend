import App from "./App.js";

import ReactDom from "react-dom"
ReactDom.render(
    <div>
        <App/>
    </div>,document.getElementById("root")
)